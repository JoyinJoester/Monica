async function handleWebDavRequest(request) {
  console.log(`[Background] ${request.method} ${request.url}`);
  try {
    const headers = { ...request.headers };
    let requestBody;
    if (request.body && headers["X-Content-Base64"] === "true") {
      delete headers["X-Content-Base64"];
      const binaryString = atob(request.body);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      requestBody = bytes;
    } else if (request.body && ["PUT", "POST", "PROPFIND"].includes(request.method)) {
      requestBody = request.body;
    }
    const fetchOptions = {
      method: request.method,
      headers,
      body: requestBody
    };
    const response = await fetch(request.url, fetchOptions);
    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key] = value;
    });
    const contentType = response.headers.get("content-type") || "";
    const isBinary = contentType.includes("octet-stream") || contentType.includes("zip") || request.method === "GET";
    let responseBody;
    let arrayBuffer;
    if (isBinary && response.ok) {
      const buffer = await response.arrayBuffer();
      arrayBuffer = Array.from(new Uint8Array(buffer));
    } else {
      responseBody = await response.text();
    }
    return {
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      body: responseBody,
      arrayBuffer
    };
  } catch (error) {
    const err = error;
    console.error("[Background] WebDAV request failed:", err);
    return {
      success: false,
      error: err.message || "Network error"
    };
  }
}
const STORAGE_KEY = "monica_vault";
const MASTER_PASSWORD_HASH_KEY = "monica_master_hash";
const MASTER_PASSWORD_SALT_KEY = "monica_master_salt";
async function hashPassword(password, saltArray) {
  const encoder = new TextEncoder();
  const salt = new Uint8Array(saltArray);
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: salt.buffer,
      iterations: 1e5,
      hash: "SHA-256"
    },
    keyMaterial,
    256
  );
  return btoa(String.fromCharCode(...new Uint8Array(bits)));
}
async function verifyMasterPassword(password) {
  try {
    const result = await chrome.storage.local.get([MASTER_PASSWORD_HASH_KEY, MASTER_PASSWORD_SALT_KEY]);
    const storedHash = result[MASTER_PASSWORD_HASH_KEY];
    const saltBase64 = result[MASTER_PASSWORD_SALT_KEY];
    if (!storedHash || !saltBase64) {
      console.log("[Background] No master password hash found");
      return false;
    }
    const saltArray = atob(saltBase64).split("").map((c) => c.charCodeAt(0));
    const hash = await hashPassword(password, saltArray);
    console.log("[Background] Verifying password, hash match:", hash === storedHash);
    return hash === storedHash;
  } catch (error) {
    console.error("[Background] Password verification error:", error);
    return false;
  }
}
async function getPasswordsFromStorage() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const rawItems = result[STORAGE_KEY];
    if (!rawItems || !Array.isArray(rawItems) || rawItems.length === 0) {
      return [];
    }
    return rawItems.filter((item) => item.itemType === 0).map((item) => ({
      id: item.id,
      title: item.title,
      username: item.itemData?.username || "",
      password: item.itemData?.password || "",
      website: item.itemData?.website || ""
    }));
  } catch (error) {
    console.error("[Background] Failed to get passwords:", error);
    return [];
  }
}
function matchPasswordsByUrl(passwords, url) {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.replace(/^www\./, "").toLowerCase();
    return passwords.filter((p) => {
      if (!p.website) return false;
      const pwdDomain = p.website.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase();
      return domain.includes(pwdDomain) || pwdDomain.includes(domain);
    });
  } catch {
    return [];
  }
}
async function getAllPasswords() {
  return getPasswordsFromStorage();
}
async function getTotpsFromStorage() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const rawItems = result[STORAGE_KEY];
    if (!rawItems || !Array.isArray(rawItems) || rawItems.length === 0) {
      return [];
    }
    return rawItems.filter((item) => item.itemType === 1).map((item) => ({
      id: item.id,
      title: item.title,
      issuer: item.itemData?.issuer || "",
      accountName: item.itemData?.accountName || "",
      secret: item.itemData?.secret || "",
      period: item.itemData?.period || 30,
      digits: item.itemData?.digits || 6,
      algorithm: item.itemData?.algorithm || "SHA1"
    }));
  } catch (error) {
    console.error("[Background] Failed to get TOTPs:", error);
    return [];
  }
}
function matchTotpsByUrl(totps, url) {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.replace(/^www\./, "").toLowerCase();
    const domainParts = domain.split(".");
    const siteName = domainParts.length > 1 ? domainParts[domainParts.length - 2] : domain;
    return totps.filter((t) => {
      const issuer = (t.issuer || "").toLowerCase();
      const title = (t.title || "").toLowerCase();
      const account = (t.accountName || "").toLowerCase();
      return issuer.includes(siteName) || title.includes(siteName) || account.includes(siteName) || siteName.includes(issuer) || domain.includes(issuer) || issuer.includes(domain.split(".")[0]);
    });
  } catch {
    return [];
  }
}
function generateTotpCode(totp) {
  try {
    const period = totp.period || 30;
    const epoch = Math.floor(Date.now() / 1e3);
    const timeRemaining = period - epoch % period;
    return {
      code: "------",
      timeRemaining
    };
  } catch (error) {
    console.error("[Background] TOTP generation failed:", error);
    return null;
  }
}
chrome.runtime.onMessage.addListener(
  (request, _sender, sendResponse) => {
    if (request.type === "GET_PASSWORDS_FOR_AUTOFILL") {
      Promise.all([
        getPasswordsFromStorage(),
        chrome.storage.local.get("i18nextLng")
      ]).then(([passwords, langResult]) => {
        const matched = matchPasswordsByUrl(passwords, request.url);
        const lang = langResult.i18nextLng || "en";
        sendResponse({
          success: true,
          passwords,
          matchedPasswords: matched,
          lang
        });
      }).catch(() => {
        sendResponse({
          success: false,
          passwords: [],
          matchedPasswords: [],
          lang: "en"
        });
      });
      return true;
    }
    if (request.type === "GET_ALL_PASSWORDS") {
      getAllPasswords().then((passwords) => {
        sendResponse({
          success: true,
          passwords
        });
      }).catch(() => {
        sendResponse({
          success: false,
          passwords: []
        });
      });
      return true;
    }
    if (request.type === "OPEN_POPUP") {
      chrome.action.openPopup().catch(() => {
        chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
      });
      sendResponse({ success: true });
      return true;
    }
    if (request.type === "SAVE_PASSWORD") {
      saveNewPassword(request.credentials).then(() => sendResponse({ success: true })).catch((error) => sendResponse({ success: false, error: error.message }));
      return true;
    }
    if (request.type === "WEBDAV_REQUEST") {
      handleWebDavRequest(request).then(sendResponse).catch((error) => {
        sendResponse({
          success: false,
          error: error.message || "Unknown error"
        });
      });
      return true;
    }
    if (request.type === "VERIFY_MASTER_PASSWORD") {
      const verifyRequest = request;
      verifyMasterPassword(verifyRequest.password).then((verified) => {
        sendResponse({ success: true, verified });
      }).catch((error) => {
        sendResponse({ success: false, verified: false, error: error.message });
      });
      return true;
    }
    if (request.type === "GET_TOTPS_FOR_AUTOFILL") {
      const totpRequest = request;
      getTotpsFromStorage().then((totps) => {
        const matched = matchTotpsByUrl(totps, totpRequest.url);
        sendResponse({
          success: true,
          totps,
          matchedTotps: matched
        });
      }).catch(() => {
        sendResponse({
          success: false,
          totps: [],
          matchedTotps: []
        });
      });
      return true;
    }
    if (request.type === "GENERATE_TOTP_CODE") {
      const totpRequest = request;
      getTotpsFromStorage().then((totps) => {
        const totp = totps.find((t) => t.id === totpRequest.totpId);
        if (totp) {
          const result = generateTotpCode(totp);
          sendResponse({
            success: true,
            code: result?.code,
            timeRemaining: result?.timeRemaining
          });
        } else {
          sendResponse({
            success: false,
            error: "TOTP not found"
          });
        }
      }).catch((error) => {
        sendResponse({
          success: false,
          error: error.message
        });
      });
      return true;
    }
    return false;
  }
);
async function saveNewPassword(credentials) {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const rawItems = result[STORAGE_KEY];
  const items = Array.isArray(rawItems) ? rawItems : [];
  const maxId = items.reduce((max, item) => Math.max(max, item.id || 0), 0);
  const newPassword = {
    id: maxId + 1,
    itemType: 0,
    // ItemType.Password
    title: credentials.title || credentials.website,
    notes: "",
    isFavorite: false,
    sortOrder: items.length,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    itemData: {
      username: credentials.username,
      password: credentials.password,
      website: credentials.website,
      category: "default"
    }
  };
  items.push(newPassword);
  await chrome.storage.local.set({ [STORAGE_KEY]: items });
  console.log("[Monica] Password saved:", newPassword.title);
}
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[Monica] Extension installed");
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://") || tab.url.startsWith("about:") || tab.url.startsWith("edge://") || tab.url.startsWith("file://")) {
      continue;
    }
    if (tab.id) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"]
        });
      } catch (err) {
        if (!err?.message?.includes("Cannot access contents of the page")) {
          console.log("[Monica] Failed to inject into existing tab:", tab.url, err);
        }
      }
    }
  }
});
